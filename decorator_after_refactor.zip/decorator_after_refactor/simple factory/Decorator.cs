﻿

namespace decoratorpattern
{
    public interface ICakeDecorator :ICake
    {
        void Decorate(string message);
    }

    public class CakeDecorator : ICakeDecorator
    {
        private readonly ICake _cake;

        public CakeDecorator(ICake cake)
        {
            _cake = cake;
        }

        public void AddLayer(string layer)
        {
            _cake.AddLayer(layer);
        }

        public void Decorate(string message)
        {
            _cake.AddLayer(message);
        }

        public void ShowAllLayers()
        {
            _cake.ShowAllLayers();
        }
    }

}
