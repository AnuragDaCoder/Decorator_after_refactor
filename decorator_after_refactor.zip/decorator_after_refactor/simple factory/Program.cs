﻿// See https://aka.ms/new-console-template for more information



using decoratorpattern;

StrawberryCake cakeobj = new();
CakeDecorator decoratorObj = new CakeDecorator(cakeobj);
decoratorObj.Decorate("Happy Birthday Anurag");
decoratorObj.ShowAllLayers();
